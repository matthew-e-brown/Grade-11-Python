If you do a couple games before marking, be sure to email me
highscores.txt @ greatwarlockthree@gmail.com so that I can
keep your highscores and they won't be lost forever ;)